To archive sale orders, you need to:

1.  Open the tree view of sale orders.
2.  Select a sale order (in status Locked or Cancelled) you want to
    archive.
3.  Click on Action \> Archive. Confirm.
4.  The sale order is now archived.

To unarchive sale orders, you need to:

1.  Open the tree view of sale orders.
2.  In the filter box select the Archived filter. The list of archived
    sale orders will be displayed.
3.  Select the sale order (in status Locked or Cancelled) you want to
    restore to Active.
4.  Click on the Action \> Unarchive.
5.  The sale order is now active.
