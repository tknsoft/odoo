- Andrea Stirpe \<<a.stirpe@onestein.nl>\>
- Kinner Vachhani
- Ruchir Shukla \<<ruchir@bizzappdev.com>\>
- [Heliconia Solutions Pvt. Ltd.](https://www.heliconia.io)
  - Bhavesh Heliconia

