- Telmo Santos \<telmo.santos@camptocamp.com\>

- Matthieu Méquignon \<matthieu.mequignon@camptocamp.com\>

- Simone Orsi \<simahawk@gmail.com\>

- Thierry Ducrest \<thierry.ducrest@camptocamp.com\>

- Sébastien Alix \<sebastien.alix@camptocamp.com\>

- [Trobz](https://trobz.com):  
  - Hai Lang \<hailn@trobz.com\>
