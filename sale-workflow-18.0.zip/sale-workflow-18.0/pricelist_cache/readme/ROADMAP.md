- Use job dependencies. If pricelist a is based on b, then job a should
  depend on job b.
- In tests do not depend on odoo demo data which might change anytime and break the tests