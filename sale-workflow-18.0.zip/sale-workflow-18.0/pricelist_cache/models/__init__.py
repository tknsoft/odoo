from . import product_pricelist
from . import product_pricelist_item
from . import product_pricelist_cache
from . import product_product
from . import res_partner
