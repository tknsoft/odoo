Create stock related workflows with more or less automatization and
apply it on sales orders.

Workflows are extended with:

- Apply default values:
  - Packing Policy (partial, complete)
- Apply automatic actions:
  - Confirm the picking
