#. Go to *Sales > Configuration > Quotations & Orders*.
#. Check the Skip Service products for Sale Delivery State checkbox to automatically set the field Skip Delivery State in sale order lines to True when the line contains a service product.
