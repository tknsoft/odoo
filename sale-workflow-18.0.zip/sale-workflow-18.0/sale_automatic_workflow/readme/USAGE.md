To use this module, you need to:

1.  Go to *Sale \> Configuration \> Automatic Workflow \> Automatic Workflow
2.  You can create/edit/delete automatic workflow
