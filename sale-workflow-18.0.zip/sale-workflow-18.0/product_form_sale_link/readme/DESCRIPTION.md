This module adds a button on product forms with a link to sale order
lines for that product.
