Go to Sales \> Products \> Products

Choose a product and click on 'Sales' button.

![image](https://user-images.githubusercontent.com/19529533/61035935-5ec0ef80-a3c8-11e9-836a-4aca2e7dec70.png)
