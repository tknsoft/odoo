To configure this module, you need to:

1. Go to Settings > Sales > Quotations & Orders > Blocking sales due to lack of stock
2. Fill *Field to compare against the quantity demanded*. Possible values:

  - *virtual_available_at_date*: Planned quantity to be in stock on the day of delivery
  - *qty_available_today*: Quantity available in stock today
  - *free_qty_today*: Quantity available without reserve in stock

3. Fill *Groups allowed to bypass the block*
