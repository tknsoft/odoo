This module was developed because sometimes you don't want to allow a sale to be confirmed when there is no enough product to sold.

It will be useful for you if selling more than you have in stock or planned is not a desired behaviour.
