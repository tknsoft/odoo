This module removes the order's salesperson from default followers.
