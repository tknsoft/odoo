The migration of this module from 13.0 to 14.0 was financially supported
by Camptocamp.
The migration of this module from 14.0 to 18.0 was financially supported by Camptocamp.
