On each partner, you can check "Sales Orders" on the "In copy of" field.
