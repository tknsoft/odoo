This module allows you to configure partners that will be automatically
in copy of their company's Sales Orders.
