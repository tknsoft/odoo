When this module is installed, each sale order you confirm will generate
one delivery order per requested date indicated in the sale order lines.

Furthermore, the delivery orders can be searched by selecting the
scheduled date, which is now displayed in the delivery tree view.
