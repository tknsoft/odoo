- Alex Comba \<<alex.comba@agilebg.com>\> (<https://www.agilebg.com/>)
- Carmen Rondon Regalado \<<crondon@archeti.com>\>
  (<https://odoo.archeti.com/>)
