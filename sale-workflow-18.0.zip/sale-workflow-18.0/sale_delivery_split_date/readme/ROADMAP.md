- Incompatible with
  [sale_procurement_group_by_commitment_date](https://github.com/OCA/sale-workflow/tree/12.0/sale_procurement_group_by_commitment_date)
