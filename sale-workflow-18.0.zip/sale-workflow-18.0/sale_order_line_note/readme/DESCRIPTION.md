This module add the field note on the sale order line
