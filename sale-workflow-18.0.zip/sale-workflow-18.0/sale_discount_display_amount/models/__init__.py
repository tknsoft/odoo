from . import res_company
from . import res_config_settings
from . import sale_order
from . import sale_order_line
