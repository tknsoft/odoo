To configure this module, you need to:

1.  Go to Sales/Settings and check "Allow discounts on sales order
    lines"
2.  Go to Sales/Settings and check or uncheck "Show the Discount with
    TAX" depending on your needs
