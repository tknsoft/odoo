To use this module, you need to:

1.  Go on a sale order
2.  Set a discount on a line
3.  The value of the discount is dislayed in the total section as well
    as the total without it.
