This module adds functional fields to show sale order in the company
currency: amount total.

1.  For tree view, when you have SO in multiple currencies, Odoo sums
    them up regardless the different currencies. This module adds a
    column & sums in the company's currency.
2.  The field is also shown in form view after the total.
