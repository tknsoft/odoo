The partner set in the sales order can order only if he/she has a
commercial entity that is listed as one of the partners for which the
products can be manufactured for.
