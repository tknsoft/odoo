- [Camptocamp](https://www.camptocamp.com):
  - Carlos Serra-Toro \<<carlos.serra@camptocamp.com>\>
  - Simone Orsi \<<simahawk@gmail.com>\>
  - Thierry Ducrest \<<thierry.ducrest@camptocamp.com>\>

- [Trobz](https://trobz.com):
  - Son Ho \<<sonhd@trobz.com>\>
  - Nhan Tran \<<nhant@trobz.com>\>
