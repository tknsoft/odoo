To use this module, you need to:

- Click at "Cancel Order" button from a sales order which state equal to
  Draft, Quotation or Sales Order
- A wizard will show a list of cancel reasons
- Choose a reason and confirm cancellation, the reason will be stamped
  in the sales order
