from . import test_auto_workflow_stock_job
