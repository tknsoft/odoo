This module use Queue Jobs to process stock-related workflows in sales.
