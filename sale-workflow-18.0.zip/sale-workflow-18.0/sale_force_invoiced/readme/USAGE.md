1.  Create a sales order and confirm it.
2.  Deliver the products/services.
3.  Create an invoice and reduce the invoiced quantity. The sales order
    invoicing status is 'To Invoice'.
4.  Check the field 'Force Invoiced'. The sales order invoicing status
    and Sale Order Line invoicing status will be 'Invoiced'.
