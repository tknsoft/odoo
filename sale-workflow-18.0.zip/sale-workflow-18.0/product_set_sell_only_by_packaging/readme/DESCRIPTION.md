Glue module between sell_only_by_packaging and sale_product_set_packaging_qty.
If sell_only_by_packaging is ON and there are product set lines without
packaging selected, a warning is displayed in the product form and quick
link to all involved lines allows to review them.
