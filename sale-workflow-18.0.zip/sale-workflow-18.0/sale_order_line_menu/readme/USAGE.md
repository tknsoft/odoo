Menu option available at Sales \> Orders \> Order Lines.
