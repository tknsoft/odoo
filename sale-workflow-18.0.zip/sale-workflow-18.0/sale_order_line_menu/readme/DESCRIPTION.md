Adds a menu item and some views to navigate through Sale Order lines.
