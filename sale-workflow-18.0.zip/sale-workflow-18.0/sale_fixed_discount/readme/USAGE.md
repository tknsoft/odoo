To use this module, you need to:

1.  Go to *Sales*.
2.  Create a Sales Order and specify the type of discount and
    fixed/percent discount in a line.
