This module extends the functionality of Sales to allow you to apply
fixed amount discount at sales order line level.

The module also extends the sales order report to show fixed discount.
