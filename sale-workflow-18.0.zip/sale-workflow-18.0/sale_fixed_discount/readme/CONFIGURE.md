To configure this module, you need to:

1.  Go to *Sales \> Configuration \> Settings*.
2.  In the *Pricing* section select *Discounts* option to grant
    discounts on sales order lines.
