This module depends on module 'account_invoice_fixed_discount',
available in
<https://github.com/OCA/account-invoicing/tree/18.0/account_invoice_fixed_discount>
