This module allows to set a period at which a workflow is going to be
executed.

The period of execution can be set in seconds in the workflow
configuration. The next execution time is displayed below it.

Another option Enforce on creation time can be used so only sales
created before the last execution will be processed.
