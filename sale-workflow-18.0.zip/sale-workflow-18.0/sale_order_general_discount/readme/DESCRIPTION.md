This module allows to set a general discount in a sales order. This
general discount is set to each line order in the standard discount
field.

You can configure:  
- a default general discount on customers
- On each product define if general discount is applied
