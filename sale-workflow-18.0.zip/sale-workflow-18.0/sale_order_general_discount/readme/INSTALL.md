You need to install sale_management module for accessing the needed
menus.
