If you are going to use Customer sale warning and Product warning, for
setting corresponding information, you need to:

1.  Go to *Settings \> User & Companies \> Users*.
2.  Edit your user.
3.  Check "A warning can be set on a product or a customer (Sale)"
    group.
4.  Install sale_management addon.
